var searchData=
[
  ['queryresult',['QueryResult',['../structfaiss_1_1RangeSearchPartialResult_1_1QueryResult.html',1,'faiss::RangeSearchPartialResult']]]
];
