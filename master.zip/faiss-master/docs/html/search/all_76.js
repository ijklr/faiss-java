var searchData=
[
  ['val',['val',['../structfaiss_1_1HeapArray.html#a4b131abb659e7d0ee315223270deac53',1,'faiss::HeapArray']]],
  ['vecs',['vecs',['../structfaiss_1_1IndexIVFFlat.html#a52f87a2c6a9282b5b74a8615fef1b4b7',1,'faiss::IndexIVFFlat']]],
  ['vectortransform',['VectorTransform',['../structfaiss_1_1VectorTransform.html',1,'faiss']]],
  ['vectortransform',['VectorTransform',['../structfaiss_1_1VectorTransform.html#a137f48bab695736f0b1d79a50cddc858',1,'faiss::VectorTransform']]],
  ['verbose',['verbose',['../structfaiss_1_1ParameterSpace.html#a7a9f2292c4e0ac3aad569434edea87b0',1,'faiss::ParameterSpace::verbose()'],['../structfaiss_1_1Index.html#a5590d847c5c2b958affd2a05e58a6f23',1,'faiss::Index::verbose()'],['../structfaiss_1_1ProductQuantizer.html#a1e4056fa3938ed8c9fe701e90d94ad95',1,'faiss::ProductQuantizer::verbose()']]],
  ['view',['view',['../classfaiss_1_1gpu_1_1Tensor.html#a3095eaec5711fe697c16c21598a8ddc1',1,'faiss::gpu::Tensor::view(DataPtrType at)'],['../classfaiss_1_1gpu_1_1Tensor.html#a67ccf916f78dacf0ae0d4816a663eb3f',1,'faiss::gpu::Tensor::view()'],['../classfaiss_1_1gpu_1_1Tensor.html#ad16d6d4cd302805370d21ef1a12a21f6',1,'faiss::gpu::Tensor::view(std::initializer_list&lt; IndexT &gt; sizes)'],['../classfaiss_1_1gpu_1_1detail_1_1SubTensor.html#a0ea642a74fc7070130a4a20635dc7b3c',1,'faiss::gpu::detail::SubTensor::view()']]]
];
