var searchData=
[
  ['alloc_5ftype_5fmmap',['Alloc_type_mmap',['../structfaiss_1_1IndexIVFPQCompact.html#ab2698c5d65644a171c53ffe39e420b70a38c1b1ed9ebdbd4b0047be13080094bb',1,'faiss::IndexIVFPQCompact']]],
  ['alloc_5ftype_5fnew',['Alloc_type_new',['../structfaiss_1_1IndexIVFPQCompact.html#ab2698c5d65644a171c53ffe39e420b70acf2d6ba8878a2778383adc32593ba8e6',1,'faiss::IndexIVFPQCompact']]],
  ['alloc_5ftype_5fnone',['Alloc_type_none',['../structfaiss_1_1IndexIVFPQCompact.html#ab2698c5d65644a171c53ffe39e420b70a3d58d7b26146791f0fe34b35a9b0fd95',1,'faiss::IndexIVFPQCompact']]]
];
