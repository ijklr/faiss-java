var searchData=
[
  ['vectortransform',['VectorTransform',['../structfaiss_1_1VectorTransform.html',1,'faiss']]]
];
