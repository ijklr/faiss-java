var searchData=
[
  ['nopdistancecorrection',['NopDistanceCorrection',['../structfaiss_1_1NopDistanceCorrection.html',1,'faiss']]],
  ['notypetensor',['NoTypeTensor',['../classfaiss_1_1gpu_1_1NoTypeTensor.html',1,'faiss::gpu']]]
];
