var searchData=
[
  ['argsort',['ArgSort',['../structfaiss_1_1ArgSort.html',1,'faiss']]],
  ['autotunecriterion',['AutoTuneCriterion',['../structfaiss_1_1AutoTuneCriterion.html',1,'faiss']]]
];
