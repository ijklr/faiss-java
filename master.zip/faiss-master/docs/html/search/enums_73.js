var searchData=
[
  ['search_5ftype_5ft',['Search_type_t',['../structfaiss_1_1IndexPQ.html#a4fa05430935a02b62b7c15c9840c42fe',1,'faiss::IndexPQ']]]
];
