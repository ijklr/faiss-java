var searchData=
[
  ['zero',['zero',['../classfaiss_1_1gpu_1_1DeviceTensor.html#af9f54565070c44a6147eab471e38af4b',1,'faiss::gpu::DeviceTensor::zero()'],['../classfaiss_1_1gpu_1_1HostTensor.html#a2d5c663fc9f28312a794615e38501cc0',1,'faiss::gpu::HostTensor::zero()']]]
];
