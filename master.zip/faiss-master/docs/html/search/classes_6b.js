var searchData=
[
  ['kerneltimer',['KernelTimer',['../classfaiss_1_1gpu_1_1KernelTimer.html',1,'faiss::gpu']]]
];
