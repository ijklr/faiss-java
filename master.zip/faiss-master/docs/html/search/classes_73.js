var searchData=
[
  ['score3computer',['Score3Computer',['../structfaiss_1_1Score3Computer.html',1,'faiss']]],
  ['score3computer_3c_20float_2c_20double_20_3e',['Score3Computer&lt; float, double &gt;',['../structfaiss_1_1Score3Computer.html',1,'faiss']]],
  ['segmentedreduce',['SegmentedReduce',['../structfaiss_1_1gpu_1_1SegmentedReduce.html',1,'faiss::gpu']]],
  ['semisortedarray',['SemiSortedArray',['../structfaiss_1_1SemiSortedArray.html',1,'faiss']]],
  ['simulatedannealingoptimizer',['SimulatedAnnealingOptimizer',['../structfaiss_1_1SimulatedAnnealingOptimizer.html',1,'faiss']]],
  ['simulatedannealingparameters',['SimulatedAnnealingParameters',['../structfaiss_1_1SimulatedAnnealingParameters.html',1,'faiss']]],
  ['sortedarray',['SortedArray',['../structfaiss_1_1SortedArray.html',1,'faiss']]],
  ['stack',['Stack',['../structfaiss_1_1gpu_1_1StackDeviceMemory_1_1Stack.html',1,'faiss::gpu::StackDeviceMemory']]],
  ['stackdevicememory',['StackDeviceMemory',['../classfaiss_1_1gpu_1_1StackDeviceMemory.html',1,'faiss::gpu']]],
  ['standardgpuresources',['StandardGpuResources',['../classfaiss_1_1gpu_1_1StandardGpuResources.html',1,'faiss::gpu']]],
  ['subtensor',['SubTensor',['../classfaiss_1_1gpu_1_1detail_1_1SubTensor.html',1,'faiss::gpu::detail']]],
  ['subtensor_3c_20tensortype_2c_200_2c_20ptrtraits_20_3e',['SubTensor&lt; TensorType, 0, PtrTraits &gt;',['../classfaiss_1_1gpu_1_1detail_1_1SubTensor_3_01TensorType_00_010_00_01PtrTraits_01_4.html',1,'faiss::gpu::detail']]],
  ['sum',['Sum',['../structfaiss_1_1gpu_1_1Sum.html',1,'faiss::gpu']]]
];
