var searchData=
[
  ['_7edevicetensor',['~DeviceTensor',['../classfaiss_1_1gpu_1_1DeviceTensor.html#a79e4a48f4e5dc6be1cce1d7a59bdeae5',1,'faiss::gpu::DeviceTensor']]],
  ['_7ehosttensor',['~HostTensor',['../classfaiss_1_1gpu_1_1HostTensor.html#a5dab0d97255fed9b1da4fc7c33a89621',1,'faiss::gpu::HostTensor']]],
  ['_7ekerneltimer',['~KernelTimer',['../classfaiss_1_1gpu_1_1KernelTimer.html#af9883350bf0732b2452f1ce4670266fa',1,'faiss::gpu::KernelTimer']]],
  ['_7eworkerthread',['~WorkerThread',['../classfaiss_1_1gpu_1_1WorkerThread.html#ac1a9c44f38ea5345a650da04b032d41b',1,'faiss::gpu::WorkerThread']]]
];
