var searchData=
[
  ['metrictype',['MetricType',['../namespacefaiss.html#afd12191c638da74760ff397cf319752c',1,'faiss']]]
];
