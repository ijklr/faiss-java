var searchData=
[
  ['alloc_5ftype_5ft',['Alloc_type_t',['../structfaiss_1_1IndexIVFPQCompact.html#ab2698c5d65644a171c53ffe39e420b70',1,'faiss::IndexIVFPQCompact']]]
];
