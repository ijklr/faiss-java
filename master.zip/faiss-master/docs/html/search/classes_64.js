var searchData=
[
  ['defaultptrtraits',['DefaultPtrTraits',['../structfaiss_1_1gpu_1_1traits_1_1DefaultPtrTraits.html',1,'faiss::gpu::traits']]],
  ['defaultptrtraits_3c_20float_20_3e',['DefaultPtrTraits&lt; float &gt;',['../structfaiss_1_1gpu_1_1traits_1_1DefaultPtrTraits.html',1,'faiss::gpu::traits']]],
  ['devicememory',['DeviceMemory',['../classfaiss_1_1gpu_1_1DeviceMemory.html',1,'faiss::gpu']]],
  ['devicememoryreservation',['DeviceMemoryReservation',['../classfaiss_1_1gpu_1_1DeviceMemoryReservation.html',1,'faiss::gpu']]],
  ['devicescope',['DeviceScope',['../classfaiss_1_1gpu_1_1DeviceScope.html',1,'faiss::gpu']]],
  ['devicetensor',['DeviceTensor',['../classfaiss_1_1gpu_1_1DeviceTensor.html',1,'faiss::gpu']]],
  ['devicetensor_3c_20float_2c_201_2c_20true_20_3e',['DeviceTensor&lt; float, 1, true &gt;',['../classfaiss_1_1gpu_1_1DeviceTensor.html',1,'faiss::gpu']]],
  ['devicetensor_3c_20float_2c_202_2c_20true_20_3e',['DeviceTensor&lt; float, 2, true &gt;',['../classfaiss_1_1gpu_1_1DeviceTensor.html',1,'faiss::gpu']]],
  ['devicetensor_3c_20float_2c_203_2c_20true_20_3e',['DeviceTensor&lt; float, 3, true &gt;',['../classfaiss_1_1gpu_1_1DeviceTensor.html',1,'faiss::gpu']]],
  ['devicevector',['DeviceVector',['../classfaiss_1_1gpu_1_1DeviceVector.html',1,'faiss::gpu']]],
  ['devicevector_3c_20char_20_3e',['DeviceVector&lt; char &gt;',['../classfaiss_1_1gpu_1_1DeviceVector.html',1,'faiss::gpu']]]
];
