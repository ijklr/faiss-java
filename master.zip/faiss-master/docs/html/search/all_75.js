var searchData=
[
  ['upcastinner',['upcastInner',['../classfaiss_1_1gpu_1_1Tensor.html#a70308137b566362d4cc37d3e71b3ae98',1,'faiss::gpu::Tensor']]],
  ['upcastouter',['upcastOuter',['../classfaiss_1_1gpu_1_1Tensor.html#ad6df1805b76f74018bc94fffab8987ac',1,'faiss::gpu::Tensor']]],
  ['update_5fbounds',['update_bounds',['../structfaiss_1_1ParameterSpace.html#ab7039882ec68aabc6c52cff883f75c28',1,'faiss::ParameterSpace']]],
  ['update_5fi_5fcross',['update_i_cross',['../structfaiss_1_1Score3Computer.html#acf371848bac76ba275ceb5e10f805d33',1,'faiss::Score3Computer']]],
  ['update_5findex',['update_index',['../structfaiss_1_1ClusteringParameters.html#a27d6192097920fa981cff0acedfaac91',1,'faiss::ClusteringParameters']]],
  ['update_5fj_5fline',['update_j_line',['../structfaiss_1_1Score3Computer.html#a98da6005edbb5ec26311bc947866122d',1,'faiss::Score3Computer']]],
  ['update_5fk',['update_k',['../structfaiss_1_1Score3Computer.html#a227601c3dc8779bb13747ba04934e0c8',1,'faiss::Score3Computer']]],
  ['update_5fpermutation',['update_permutation',['../structfaiss_1_1IndexFlat1D.html#ac7466c6c9b1e9e81ea19b846ddb8209e',1,'faiss::IndexFlat1D']]],
  ['updatedevicelistinfo_5f',['updateDeviceListInfo_',['../classfaiss_1_1gpu_1_1IVFBase.html#acc695610c9513952b8d234dc0db78e5c',1,'faiss::gpu::IVFBase::updateDeviceListInfo_(cudaStream_t stream)'],['../classfaiss_1_1gpu_1_1IVFBase.html#ae90724e307bbfe49554a2ab77fbd1764',1,'faiss::gpu::IVFBase::updateDeviceListInfo_(const std::vector&lt; int &gt; &amp;listIds, cudaStream_t stream)']]],
  ['use_5fprecomputed_5ftable',['use_precomputed_table',['../structfaiss_1_1IndexIVFPQ.html#a1c66ff073c18a1edbe8444c24d870583',1,'faiss::IndexIVFPQ']]],
  ['usefloat16',['useFloat16',['../structfaiss_1_1gpu_1_1GpuClonerOptions.html#ac7cc57d6091d6a79ea6020bf8d1fbe27',1,'faiss::gpu::GpuClonerOptions']]],
  ['usefloat16coarsequantizer',['useFloat16CoarseQuantizer',['../structfaiss_1_1gpu_1_1GpuClonerOptions.html#a85f3093908b6e9a503c24bb226b17b1b',1,'faiss::gpu::GpuClonerOptions']]],
  ['usefloat16coarsequantizer_5f',['useFloat16CoarseQuantizer_',['../classfaiss_1_1gpu_1_1GpuIndexIVF.html#a571ba3623dd0f23ae11e5300eb6baf61',1,'faiss::gpu::GpuIndexIVF']]],
  ['useprecomputed',['usePrecomputed',['../structfaiss_1_1gpu_1_1GpuClonerOptions.html#abc9c607f2dfc9f23942a523fb49c63fe',1,'faiss::gpu::GpuClonerOptions']]]
];
