var searchData=
[
  ['onerecallatrcriterion',['OneRecallAtRCriterion',['../structfaiss_1_1OneRecallAtRCriterion.html',1,'faiss']]],
  ['operatingpoint',['OperatingPoint',['../structfaiss_1_1OperatingPoint.html',1,'faiss']]],
  ['operatingpoints',['OperatingPoints',['../structfaiss_1_1OperatingPoints.html',1,'faiss']]],
  ['opqmatrix',['OPQMatrix',['../structfaiss_1_1OPQMatrix.html',1,'faiss']]],
  ['options',['Options',['../structOptions.html',1,'']]]
];
