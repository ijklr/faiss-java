var searchData=
[
  ['detail',['detail',['../namespacefaiss_1_1gpu_1_1detail.html',1,'faiss::gpu']]],
  ['faiss',['faiss',['../namespacefaiss.html',1,'']]],
  ['finalblockmerge',['FinalBlockMerge',['../structfaiss_1_1gpu_1_1FinalBlockMerge.html',1,'faiss::gpu']]],
  ['finalblockmerge_3c_201_2c_20numthreads_2c_20k_2c_20v_2c_20numwarpq_2c_20dir_2c_20comp_20_3e',['FinalBlockMerge&lt; 1, NumThreads, K, V, NumWarpQ, Dir, Comp &gt;',['../structfaiss_1_1gpu_1_1FinalBlockMerge_3_011_00_01NumThreads_00_01K_00_01V_00_01NumWarpQ_00_01Dir_00_01Comp_01_4.html',1,'faiss::gpu']]],
  ['finalblockmerge_3c_202_2c_20numthreads_2c_20k_2c_20v_2c_20numwarpq_2c_20dir_2c_20comp_20_3e',['FinalBlockMerge&lt; 2, NumThreads, K, V, NumWarpQ, Dir, Comp &gt;',['../structfaiss_1_1gpu_1_1FinalBlockMerge_3_012_00_01NumThreads_00_01K_00_01V_00_01NumWarpQ_00_01Dir_00_01Comp_01_4.html',1,'faiss::gpu']]],
  ['finalblockmerge_3c_204_2c_20numthreads_2c_20k_2c_20v_2c_20numwarpq_2c_20dir_2c_20comp_20_3e',['FinalBlockMerge&lt; 4, NumThreads, K, V, NumWarpQ, Dir, Comp &gt;',['../structfaiss_1_1gpu_1_1FinalBlockMerge_3_014_00_01NumThreads_00_01K_00_01V_00_01NumWarpQ_00_01Dir_00_01Comp_01_4.html',1,'faiss::gpu']]],
  ['finalblockmerge_3c_208_2c_20numthreads_2c_20k_2c_20v_2c_20numwarpq_2c_20dir_2c_20comp_20_3e',['FinalBlockMerge&lt; 8, NumThreads, K, V, NumWarpQ, Dir, Comp &gt;',['../structfaiss_1_1gpu_1_1FinalBlockMerge_3_018_00_01NumThreads_00_01K_00_01V_00_01NumWarpQ_00_01Dir_00_01Comp_01_4.html',1,'faiss::gpu']]],
  ['find_5fduplicates',['find_duplicates',['../structfaiss_1_1IndexIVFPQ.html#aee355b57acde203a3caed46a93e16a3c',1,'faiss::IndexIVFPQ']]],
  ['flatindex',['FlatIndex',['../classfaiss_1_1gpu_1_1FlatIndex.html',1,'faiss::gpu']]],
  ['fsize',['fsize',['../structfaiss_1_1IndexIVFFlatIPBounds.html#a32e550879d0bf5eecf0a939eb25b3c0c',1,'faiss::IndexIVFFlatIPBounds']]],
  ['fvec_5fl2sqr',['fvec_L2sqr',['../namespacefaiss.html#a7466bd32de31640860393a701eaac5ad',1,'faiss']]],
  ['fvec_5fmadd',['fvec_madd',['../namespacefaiss.html#a40328c31abd0bbba5bd95d7de951e847',1,'faiss']]],
  ['fvec_5fmadd_5fand_5fargmin',['fvec_madd_and_argmin',['../namespacefaiss.html#a9da63b8bb84460f5e8ccf8e17622cc7a',1,'faiss']]],
  ['fvec_5fnorm_5fl2sqr',['fvec_norm_L2sqr',['../namespacefaiss.html#a7a49180ebf10e643217bbce5862c7f84',1,'faiss']]],
  ['fvec_5fnorms_5fl2',['fvec_norms_L2',['../namespacefaiss.html#a40265aa2cbbe57e5b223c2c7dafac31f',1,'faiss']]],
  ['fvec_5fnorms_5fl2sqr',['fvec_norms_L2sqr',['../namespacefaiss.html#abce90e9d55d6838c7a37422285192d54',1,'faiss']]],
  ['fvecs_5fmaybe_5fsubsample',['fvecs_maybe_subsample',['../namespacefaiss.html#a14884d253128c7af5891a65082ad7dc6',1,'faiss']]]
];
