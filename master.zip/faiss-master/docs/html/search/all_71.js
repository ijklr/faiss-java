var searchData=
[
  ['quantizer',['quantizer',['../structfaiss_1_1IndexIVF.html#a4b40cc7a70dff41196a3b8769586667a',1,'faiss::IndexIVF']]],
  ['quantizer_5f',['quantizer_',['../classfaiss_1_1gpu_1_1GpuIndexIVF.html#aaa7dd748e3cbd7ef68f2e384ac503eab',1,'faiss::gpu::GpuIndexIVF::quantizer_()'],['../classfaiss_1_1gpu_1_1IVFBase.html#a878114abdba07c9cf7735f9c0ed594c3',1,'faiss::gpu::IVFBase::quantizer_()']]],
  ['quantizer_5ftrains_5falone',['quantizer_trains_alone',['../structfaiss_1_1IndexIVF.html#a23ee7f75f8be4472a17778f2b33875de',1,'faiss::IndexIVF']]],
  ['query',['query',['../classfaiss_1_1gpu_1_1IVFFlat.html#a6652ca90a8a30512104fc909f0a0a6b8',1,'faiss::gpu::IVFFlat::query()'],['../classfaiss_1_1gpu_1_1IVFPQ.html#ab0c458aab9a3d903f31b0e63ce16e623',1,'faiss::gpu::IVFPQ::query()']]],
  ['queryresult',['QueryResult',['../structfaiss_1_1RangeSearchPartialResult_1_1QueryResult.html',1,'faiss::RangeSearchPartialResult']]]
];
