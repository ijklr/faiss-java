var searchData=
[
  ['tensor',['Tensor',['../classfaiss_1_1gpu_1_1Tensor.html',1,'faiss::gpu']]],
  ['tensor_3c_20float_2c_20dim_2c_20contig_2c_20int_2c_20traits_3a_3adefaultptrtraits_20_3e',['Tensor&lt; float, Dim, Contig, int, traits::DefaultPtrTraits &gt;',['../classfaiss_1_1gpu_1_1Tensor.html',1,'faiss::gpu']]],
  ['tensorinfo',['TensorInfo',['../structfaiss_1_1gpu_1_1TensorInfo.html',1,'faiss::gpu']]],
  ['tensorinfooffset',['TensorInfoOffset',['../structfaiss_1_1gpu_1_1TensorInfoOffset.html',1,'faiss::gpu']]],
  ['tensorinfooffset_3c_20t_2c_2d1_20_3e',['TensorInfoOffset&lt; T,-1 &gt;',['../structfaiss_1_1gpu_1_1TensorInfoOffset_3_01T_00-1_01_4.html',1,'faiss::gpu']]],
  ['tocpucloner',['ToCPUCloner',['../structfaiss_1_1gpu_1_1ToCPUCloner.html',1,'faiss::gpu']]],
  ['togpucloner',['ToGpuCloner',['../structfaiss_1_1gpu_1_1ToGpuCloner.html',1,'faiss::gpu']]],
  ['togpuclonermultiple',['ToGpuClonerMultiple',['../structfaiss_1_1gpu_1_1ToGpuClonerMultiple.html',1,'faiss::gpu']]]
];
